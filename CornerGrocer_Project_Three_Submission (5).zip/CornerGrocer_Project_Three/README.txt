CS 210 Project Three - Corner Grocer

Included files:
- Source.cpp: complete C++ program
- CornerGrocer.vcxproj: Visual Studio project file
- CornerGrocer.vcxproj.filters: Visual Studio source-file filters
- CS210_Project_Three_Input_File.txt: purchase records used to test the program

To run:
1. Extract this ZIP to a folder.
2. Open CornerGrocer.vcxproj in Visual Studio.
3. Set Project Properties > Debugging > Working Directory to $(ProjectDir), or copy the input TXT into the executable's working directory.
4. Build and run. The program creates frequency.dat automatically.
