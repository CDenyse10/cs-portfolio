#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <algorithm>
#include <cctype>
using namespace std;

// Tracks grocery items and their purchase frequencies.
class GroceryTracker {
private:
    struct ItemRecord { string displayName; int frequency; };
    map<string, ItemRecord> itemFrequencies;

    // Normalize item names so searches ignore capitalization.
    string Normalize(const string& name) const {
        string result = name;
        transform(result.begin(), result.end(), result.begin(),
            [](unsigned char c) { return static_cast<char>(tolower(c)); });
        return result;
    }
public:
    // Read the purchase file and count each item.
    bool LoadItems(const string& fileName) {
        ifstream inputFile(fileName);
        if (!inputFile.is_open()) {
            cerr << "ERROR: Could not find " << fileName << ".\n"
                 << "Place the input file in the program's working directory.\n";
            return false;
        }
        string itemName;
        while (getline(inputFile, itemName)) {
            if (itemName.empty()) continue;
            string key = Normalize(itemName);
            auto item = itemFrequencies.find(key);
            if (item == itemFrequencies.end()) itemFrequencies[key] = {itemName, 1};
            else ++item->second.frequency;
        }
        return true;
    }

    // Return the frequency for one item, or zero if it was not found.
    int GetFrequency(const string& itemName) const {
        auto item = itemFrequencies.find(Normalize(itemName));
        return item == itemFrequencies.end() ? 0 : item->second.frequency;
    }

    // Display all item names with their frequencies.
    void PrintFrequencies() const {
        cout << "\nITEM FREQUENCIES\n----------------\n";
        if (itemFrequencies.empty()) { cout << "No grocery items were found.\n"; return; }
        for (const auto& item : itemFrequencies)
            cout << item.second.displayName << " " << item.second.frequency << '\n';
    }

    // Display one asterisk for every purchase.
    void PrintHistogram() const {
        cout << "\nGROCERY PURCHASE HISTOGRAM\n--------------------------\n";
        if (itemFrequencies.empty()) { cout << "No grocery items were found.\n"; return; }
        for (const auto& item : itemFrequencies) {
            cout << item.second.displayName << " ";
            for (int i = 0; i < item.second.frequency; ++i) cout << '*';
            cout << '\n';
        }
    }

    // Save the item frequencies to the required backup file.
    bool WriteBackup(const string& fileName) const {
        ofstream outputFile(fileName);
        if (!outputFile.is_open()) { cerr << "ERROR: Could not create " << fileName << ".\n"; return false; }
        for (const auto& item : itemFrequencies)
            outputFile << item.second.displayName << " " << item.second.frequency << '\n';
        return outputFile.good();
    }
};

int main() {
    const string inputFileName = "CS210_Project_Three_Input_File.txt";
    GroceryTracker tracker;
    cout << "====================================\n       CORNER GROCER TRACKER\n====================================\n";
    if (!tracker.LoadItems(inputFileName)) { cout << "Press Enter to close."; cin.get(); return 1; }
    cout << "Input file loaded successfully.\n";
    if (tracker.WriteBackup("frequency.dat")) cout << "Backup file frequency.dat created.\n";
    else cout << "Warning: the backup file could not be created.\n";

    string choice;
    while (true) {
        cout << "\n1. Find frequency of an item\n2. Display all item frequencies\n3. Display histogram\n4. Exit\nEnter your choice: ";
        if (!getline(cin, choice)) break;
        if (choice == "1") {
            string itemName;
            cout << "Enter the item to search for: ";
            if (!getline(cin, itemName)) break;
            cout << itemName << " was purchased " << tracker.GetFrequency(itemName) << " time(s).\n";
        } else if (choice == "2") tracker.PrintFrequencies();
        else if (choice == "3") tracker.PrintHistogram();
        else if (choice == "4") { cout << "Thank you for using Corner Grocer Tracker.\n"; break; }
        else cout << "Invalid choice. Enter 1, 2, 3, or 4.\n";
    }
    return 0;
}
